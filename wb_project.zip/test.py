﻿print("VS Code готов к работе 🚀")
